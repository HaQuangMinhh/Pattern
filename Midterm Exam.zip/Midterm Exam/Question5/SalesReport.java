public class SalesReport implements Report {

    @Override
    public void generate() {
        System.out.println("Sales report generated");
        
    }


}
