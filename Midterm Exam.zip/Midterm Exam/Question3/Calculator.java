public interface Calculator {

    int addition(); 
    int subtraction(); 
    int multiplication();
    int division(); 

    void setOperand ( int a , int b  );

}
